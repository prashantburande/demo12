#include<stdio.h>
#pragma pack(1)
struct emp
{
    int empno;
    char name[10];
    float sal;
};
void AcceptEmpInfo(struct emp *e);
void PrintEmpInfo(const struct emp *e);
int main()
{
   // struct emp e1={100};
    struct emp e1;
    printf("\n enter emp info :: ");
    AcceptEmpInfo(&e1);
    
    printf("\n emp info by struct variable\n");
    PrintEmpInfo(&e1);
    e1.sal=-10000;
    PrintEmpInfo(&e1);

    return 0;
}
void AcceptEmpInfo(struct emp *e)
{
    printf("\n enter emp no::");
    scanf("%d", &e->empno);
    printf("\n enter emp name::");
    scanf("%s", e->name);
    printf("\n enter emp sal::");
    scanf("%f", &e->sal);
    return ;
}
void PrintEmpInfo(const struct emp *e)
{
   // e->sal=-10000;
    printf("\n emp no=%d", e->empno);
    printf("\n emp name=%s", e->name);
    printf("\n emp no=%f", e->sal);
    return ;
}