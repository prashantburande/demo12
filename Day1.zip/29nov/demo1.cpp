#include<stdio.h>
#pragma pack(1)
struct emp
{
    int empno;
    char name[10];
    float sal;
};
int main()
{
    struct emp e1={100};
    struct emp *ptr=&e1;
    printf("\nsize of struct emp=%d", sizeof(struct emp));
    printf("\nsize of struct ptr=%d", sizeof(ptr));

    printf("\n enter emp info :: ");
    printf("\n enter emp no::");
    scanf("%d", &e1.empno);
    printf("\n enter emp name::");
    scanf("%s", e1.name);
    printf("\n enter emp sal::");
    scanf("%f", &e1.sal);

    printf("\n emp info by struct variable\n");
    printf("\n emp no=%d", e1.empno);
    printf("\n emp name=%s", e1.name);
    printf("\n emp no=%f", e1.sal);
    printf("\n emp info by pointer using arrow operator \n");
    printf("\n emp no=%d", ptr->empno);
    printf("\n emp name=%s", ptr->name);
    printf("\n emp no=%f", ptr->sal);
    printf("\n emp info by pointer using dot operator \n");
    printf("\n emp no=%d", (*ptr).empno);
    printf("\n emp name=%s",(*ptr).name);
    printf("\n emp no=%f", (*ptr).sal);

    printf("\n ptr=%u ptr+1=%u", ptr, ptr+1);
    printf("\n &e1=%u &e1+1=%u", &e1, &e1+1);

    return 0;
}