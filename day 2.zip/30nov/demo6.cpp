#include<stdio.h>
namespace N1
{
    int no1=200;
    int no2=300;
}
namespace N2
{
    int no1=500;
    int no3=600;
}
int no1=50;
using namespace N1;
using namespace N2;

int main()
{
    int no1=10;
    printf("\n local variable no1=%d [%u]",no1, &no1);
    printf("\n global variable ::no1=%d [%u]",::no1, &::no1);
    printf("\n variable from namespace N1 N1::no1=%d [%u]",N1::no1, &N1::no1);
    printf("\n variable from namespace N1 N1::no2=%d [%u]",N1::no2, &N1::no2);
    printf("\n variable from namespace N1 no2=%d [%u]",no2, &no2);

    printf("\n variable from namespace N2 N1::no1=%d [%u]",N2::no1, &N2::no1);
    printf("\n variable from namespace N2 N1::no3=%d [%u]",N2::no3, &N2::no3);
    printf("\n variable from namespace N2 no3=%d [%u]",no3, &no3);

    return 0;
}

// 9 questions
//  6 theory   3 code