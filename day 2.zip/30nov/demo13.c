#include <stdio.h> 
union p 
{ 
    int x; 
    char y; 
};
int main() 
{ 
    union p obj;
    obj.x=1;
    obj.y='a';
    printf("%d [%u]\n", obj.x, &obj.x);
    printf("%c[%u]\n", obj.y, &obj.y);

    obj.y='a';
    obj.x=48;
    printf("%d [%u]\n", obj.x, &obj.x);
    printf("%c[%u]%d\n", obj.y, &obj.y, obj.y);

} //big-endian and little-endian
