#include<stdio.h>
int no=100; //global
namespace N1
{
    int no=1000;
    int no1=2000;
}
int main()
{
    int no=10; //local
    printf("\n local no=%d [%u]", no, &no); // stack
    printf("\n global ::no=%d [%u]", ::no, &::no); // data segment
  // namespace_Name::Variable_name
    printf("\n variable from namespace N1 N1::no=%d [%u] ",N1::no, &N1::no);
    printf("\n variable from namespace N1 N1::no1=%d [%u] ",N1::no1, &N1::no1);
    using namespace N1;
    printf("\n variable from namespace N1 no1=%d [%u] ",no1, &no1);
    printf("\n variable local no=%d [%u] ",no, no);   
     printf("\n variable from namespace N1 N1::no=%d [%u] ",N1::no, &N1::no);



    return 0;
}