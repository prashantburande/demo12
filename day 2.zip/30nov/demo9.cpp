#include<iostream>
//#include<string.h> or #include<cstring>
#include <bits/stdc++.h>
using namespace std;
#pragma pack(1)
struct emp
{
    private: //variable or data members or field
        int empno;
        char name[20];
        float sal;
    
    public:    // member function or method
    void AcceptEmpInfo()
    {
        
        cout << "Enter emp name: ";
        cin.getline (name,20);
        cout<<"\n enter emp no::";
        cin>>empno;
       // cout<<"\n enter emp name::";
        //cin>>name;
        cout<<"\n enter emp sal::";
        cin>>sal;
        return ;
    }
    void PrintEmpInfo()
    {
        cout<<" emp no="<<empno<<endl;
        cout<<" emp name="<<name<<endl;
        cout<<" emp no="<<sal<<endl;;
        return ;
    }
};
//typedef struct emp EMP;
int main()
{
   // struct emp e1={100};
    emp e1; // struct emp e1;  e1 is variable in c or object in cpp
    cout<<"\n enter emp info :: "<<"\n";
    e1.AcceptEmpInfo();//AcceptEmpInfo(&e1);
    
    cout<<"\n emp info by struct variable"<<endl;
    e1.PrintEmpInfo();//  PrintEmpInfo(&e1);
   // e1.sal=-10000; //error
     e1.PrintEmpInfo();//  PrintEmpInfo(&e1);

    return 0;
}
