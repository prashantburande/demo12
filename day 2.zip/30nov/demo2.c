#include<stdio.h>
int no=100; //global
int main()
{
    int no=10; //local
    printf("\n no=%d [%u]", no, &no);

    return 0;
}

// stdarg.h   variable argrument fuction chaper no11 
// va_start va_end va_list