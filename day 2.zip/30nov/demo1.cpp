#include<stdio.h>
#pragma pack(1)
struct emp
{
    private: //variable or data members or field
        int empno;
        char name[10];
        float sal;
    
    public:    // member function or method
    void AcceptEmpInfo()
    {
        printf("\n enter emp no::");
        scanf("%d", &empno);
        printf("\n enter emp name::");
        scanf("%s", name);
        printf("\n enter emp sal::");
        scanf("%f", &sal);
        return ;
    }
    void PrintEmpInfo()
    {
        printf("\n emp no=%d",empno);
        printf("\n emp name=%s",name);
        printf("\n emp no=%f",sal);
        return ;
    }
};
//typedef struct emp EMP;
int main()
{
   // struct emp e1={100};
    emp e1; // struct emp e1;  e1 is variable in c or object in cpp
    printf("\n enter emp info :: ");
    e1.AcceptEmpInfo();//AcceptEmpInfo(&e1);
    
    printf("\n emp info by struct variable\n");
    e1.PrintEmpInfo();//  PrintEmpInfo(&e1);
   // e1.sal=-10000; //error
     e1.PrintEmpInfo();//  PrintEmpInfo(&e1);

    return 0;
}
