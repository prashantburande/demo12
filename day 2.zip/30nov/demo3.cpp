#include<stdio.h>
int no=100; //global
int main()
{
    int no=10; //local
    printf("\n local no=%d [%u]", no, &no); // stack
    printf("\n global ::no=%d [%u]", ::no, &::no); // data segment

    return 0;
}