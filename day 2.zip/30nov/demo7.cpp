// bool  true or false  1 byte
// wchar_t  2 bytes   unicode  16bit char
// char   ascii  0 to 255        8 bit char
#include<iostream>
int main()
{
    {
        int no1, no2;
        std::cout<<" Enter No1::";
        std::cin>>no1;
       // std::cin>>&no1; error
        std::cout<<" Enter No2::";
        std::cin>>no2;

        std::cout<<"no1="<<no1<<" &no1="<<&no1<<std::endl;
        std::cout<<"no2="<<no2<<" &no2="<<&no2<<std::endl;

    }
    return 0;
}
