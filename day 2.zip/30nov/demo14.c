#include <stdio.h>
#include <stdlib.h>
typedef union test
{
	short int no;
	char name[2];
}TEST;
int main(void)
{
	TEST t;//union test t;
	printf("\n size of t=%d", sizeof(t));
	printf("\n size of TEST=%d", sizeof(TEST));

	//t.name[0]='a';//'A';
	//t.name[1]='b';//'B';
	t.no=16961 ;// 25185;//?; //16961;
	printf("\n t.name[0]=%c [%u]", t.name[0], &t.name[0]);
	printf("\n t.name[1]=%c[%u]", t.name[1], &t.name[1]);
	printf("\n t.no=%hd [%u]", t.no, &t.no);

	return EXIT_SUCCESS;
}

//big-endian and little-endian
// A    65 00000000 01000001
// B    66 00000000 01000010

//16961    01000010 01000001
//BA

//  a   97 00000000 01100001
//  b   98 00000000 01100010

//ba       0110001001100001
 //25185   0110001001100001