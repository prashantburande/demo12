#include<iostream>
using namespace std;
int main()
{
    {
        int no1, no2;
        cout<<" Enter No1::";
        cin>>no1;
       // std::cin>>&no1; error
        cout<<" Enter No2::";
        cin>>no2;

        cout<<"no1="<<no1<<" &no1="<<&no1<<endl;
        cout<<"no2="<<no2<<" &no2="<<&no2<<endl;

    }
    {
        float no1, no2;
        cout<<" Enter No1::";
        cin>>no1;
       // std::cin>>&no1; error
        cout<<" Enter No2::";
        cin>>no2;

        cout<<"no1="<<no1<<" &no1="<<&no1<<endl;
        cout<<"no2="<<no2<<" &no2="<<&no2<<endl;

    }
    {
        char no1, no2;
        cout<<" Enter No1::";
        cin>>no1;
       // std::cin>>&no1; error
        cout<<" Enter No2::";
        cin>>no2;

        cout<<"no1="<<no1<<" &no1="<<(void*)&no1<<endl;
        cout<<"no2="<<no2<<" &no2="<<(void*)&no2<<endl;

    }
    return 0;
}
